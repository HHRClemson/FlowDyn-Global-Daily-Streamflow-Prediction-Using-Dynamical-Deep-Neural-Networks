#author: Nushrat

# Keras Model Deployment Using Django
  This is a very simple Django web application as a deployment of Keras deep learning model.
  The deep learning model has been implemented using Keras and Tensorflow. It is LSTM regression model to predict river streamflow based on historical climate time series.

The app performance inference on a test input station dataset and displays the regression score, along with predicted result plot

# Requirements:
  0. Python
  1. Tensorflow
  2. Keras
  3. Django
  
# Keras model needs to be saved in hdf5 to run inference on new data and be placed in the app folder

# You can find the details of the model in following Kaggle kernel:
  https://www.kaggle.com/vipoooool/plant-diseases-classification-using-alexnet
