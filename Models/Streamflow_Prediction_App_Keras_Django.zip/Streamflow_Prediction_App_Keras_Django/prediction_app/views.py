from django.shortcuts import render
from keras.preprocessing import image
import numpy as np
import pandas as pd
import tensorflow as tf
import matplotlib
matplotlib.use("Agg")
from keras.models import load_model
from sklearn.preprocessing import StandardScaler
from numpy import array
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import LSTM
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
import matplotlib.pyplot as plt
import base64
import datetime
from .forms import EventForm
from io import BytesIO
global graph, model

# initializing the graph
graph = tf.compat.v1.get_default_graph()


# creating a dictionary of classes
class_dict = {'Apple___Apple_scab': 0,
              'Apple___Black_rot': 1,
              'Apple___Cedar_apple_rust': 2,
              'Apple___healthy': 3,
              'Blueberry___healthy': 4,
              'Cherry_(including_sour)___Powdery_mildew': 5,
              'Cherry_(including_sour)___healthy': 6,
              'Corn_(maize)___Cercospora_leaf_spot Gray_leaf_spot': 7,
              'Corn_(maize)___Common_rust_': 8,
              'Corn_(maize)___Northern_Leaf_Blight': 9,
              'Corn_(maize)___healthy': 10,
              'Grape___Black_rot': 11,
              'Grape___Esca_(Black_Measles)': 12,
              'Grape___Leaf_blight_(Isariopsis_Leaf_Spot)': 13,
              'Grape___healthy': 14,
              'Orange___Haunglongbing_(Citrus_greening)': 15,
              'Peach___Bacterial_spot': 16,
              'Peach___healthy': 17,
              'Pepper,_bell___Bacterial_spot': 18,
              'Pepper,_bell___healthy': 19,
              'Potato___Early_blight': 20,
              'Potato___Late_blight': 21,
              'Potato___healthy': 22,
              'Raspberry___healthy': 23,
              'Soybean___healthy': 24,
              'Squash___Powdery_mildew': 25,
              'Strawberry___Leaf_scorch': 26,
              'Strawberry___healthy': 27,
              'Tomato___Bacterial_spot': 28,
              'Tomato___Early_blight': 29,
              'Tomato___Late_blight': 30,
              'Tomato___Leaf_Mold': 31,
              'Tomato___Septoria_leaf_spot': 32,
              'Tomato___Spider_mites Two-spotted_spider_mite': 33,
              'Tomato___Target_Spot': 34,
              'Tomato___Tomato_Yellow_Leaf_Curl_Virus': 35,
              'Tomato___Tomato_mosaic_virus': 36,
              'Tomato___healthy': 37}

class_names = list(class_dict.keys())


def prediction(request):
    if request.method == 'POST' and request.FILES['myfile']:
        post = request.method == 'POST'
        myfile = request.FILES['myfile']
        print(myfile.name)
        datasets = pd.read_csv(myfile.name)
        datasets = datasets.rename(columns={'Unnamed: 3': 'Value_1'})
        datasets.loc[0,'Value_1']= datasets.loc[0,' Value']
        for i in range(1, len(datasets)):
            datasets.loc[i, 'Value_1'] = datasets.loc[i-1, ' Value']
        datasets = datasets.dropna()
        num_examples = len(datasets)
        num_train = int(0.7 * num_examples)
        train_examples_x = datasets.iloc[:num_train,2:4].values.astype(float)
        train_examples_y = datasets.iloc[:num_train,4:5].values.astype(float)
        val_examples_x = datasets.iloc[num_train:,2:4].values.astype(float)
        val_examples_y = datasets.iloc[num_train:,4:5].values.astype(float)
        dates = datasets.iloc[num_train:,1].values.tolist()
        sc_x_train = StandardScaler()
        sc_y_train = StandardScaler()
        x_train = sc_x_train.fit_transform(train_examples_x)
        y_train = sc_y_train.fit_transform(train_examples_y).ravel()
        x_test=sc_x_train.transform(val_examples_x)
        observation = val_examples_y
        x_test = array(x_test).reshape(np.shape(x_test)[0], 1, 2)
        #img = image.load_img(myfile.name, target_size=(224, 224))
        #img = image.img_to_array(img)
        #img = np.expand_dims(img, axis=0)
        #img = img/255
        with graph.as_default():
            model = load_model(
                'prediction_app/model.hdf5')
            LSTM_test_predict = model.predict(x_test)
            LSTM_test_Sim = sc_y_train.inverse_transform(LSTM_test_predict)
            score = r2_score(observation, LSTM_test_Sim)
            #preds = model.predict(img)
        result = round(score,2)
        date_range=[]
        for date in dates:
            d_parsed = pd.to_datetime(date, format="%m/%d/%Y")
            date_range.append(d_parsed)
        fig, ax = plt.subplots(figsize=(12, 4))
        ax.plot(date_range, observation, label="observation")
        ax.plot(date_range, LSTM_test_Sim, label="simulation")
        ax.legend()
        ax.set_title(f"Basin: {myfile.name} NSE={r2_score(observation, LSTM_test_Sim):.2f}")
        ax.xaxis.set_tick_params(rotation=90)
        ax.set_xlabel("Date")
        _ = ax.set_ylabel("Discharge (mm/d)")
        buf = BytesIO
        plt.savefig("prediction_app"+"/"+myfile.name+"_lstm.png")
        image_path = "prediction_app"+"/"+myfile.name+"_lstm.png"
        with open(image_path, "rb") as image_file:
            image_data = base64.b64encode(image_file.read()).decode('utf-8')
        ctx = {}
        ctx["image"] = image_data
        ctx["result"] = result
        #preds = preds.flatten()
        #m = max(preds)
        #for index, item in enumerate(preds):
            #if item == m:
                #result = class_names[index]
        #return render(request, "prediction_app/prediction.html", {
            #'result': result})
        return render(request, "prediction_app/prediction.html", ctx)
    else:
        return render(request, "prediction_app/prediction.html")


def download(request):
     if request.method == 'POST' and request.POST['end_date']:
          print("Here\n")
          form = EventForm()
          # Check if the form is valid:
          if form.is_valid():
              print("Again")
     