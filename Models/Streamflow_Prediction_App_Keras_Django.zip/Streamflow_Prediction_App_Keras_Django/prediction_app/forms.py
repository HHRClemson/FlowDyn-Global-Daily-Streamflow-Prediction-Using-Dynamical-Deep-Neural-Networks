from django import forms 
  
# creating a form  
class EventForm(forms.Form):
    date = forms.DateTimeField(
        input_formats=['%d/%m/%Y %H:%M'],
        widget=forms.DateTimeInput(attrs={
            'type': 'datetime-local',
            'class': 'form-control'
        },format='%Y-%m-%dT%H:%M')
    )