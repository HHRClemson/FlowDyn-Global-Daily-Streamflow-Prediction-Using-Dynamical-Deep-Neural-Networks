from django.apps import AppConfig


class PredictionAppConfig(AppConfig):
    name = 'prediction_app'
